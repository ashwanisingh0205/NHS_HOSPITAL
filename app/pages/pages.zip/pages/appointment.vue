<template>
  <div>
    <h1>Appointment</h1>
  </div>
</template>

<script setup>
definePageMeta({
  layout: 'home'
});
</script>