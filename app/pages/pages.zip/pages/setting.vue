<template>
  <div>
    <h1>setting</h1>
  </div>
</template>

<script setup>
definePageMeta({
  layout: 'home'
});
</script>